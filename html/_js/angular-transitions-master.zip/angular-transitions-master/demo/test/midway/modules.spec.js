describe('Modules', function () {
  'use strict';
  it('should has angular-transitions defined', function () {
    expect(angular.module('angular-transitions')).not.toBeFalsy();
  });
});